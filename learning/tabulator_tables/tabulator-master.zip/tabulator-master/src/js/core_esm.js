/*=include core.js */
/*=include modules_enabled.js */

export default Tabulator;
